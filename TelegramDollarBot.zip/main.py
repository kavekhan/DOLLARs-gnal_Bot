import json
import time
from telegram import Bot, Update
from telegram.ext import Updater, CommandHandler, CallbackContext
from apscheduler.schedulers.background import BackgroundScheduler

# Load and save settings
SETTINGS_FILE = 'settings.json'

def load_settings():
    try:
        with open(SETTINGS_FILE, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        default = {
            'dollar_cash': 0,
            'dollar_today': 0,
            'dollar_tomorrow': 0,
            'euro': 0,
            'lira_toman': 0,
            'lira_istanbul': {'buy': 0, 'sell': 0}
        }
        with open(SETTINGS_FILE, 'w') as f:
            json.dump(default, f)
        return default

def save_settings(settings):
    with open(SETTINGS_FILE, 'w') as f:
        json.dump(settings, f)

# Bot token and channel id
API_TOKEN = '7592248600:AAGsfuTkzBZ6oMm1j9jm071R8i9chxEloc8'
CHANNEL_ID = '@قیمت_لحظه_ای_دلار_ارومیه'

# Command to update prices
def update_prices(update: Update, context: CallbackContext):
    text = update.message.text.replace('/update_prices', '').strip()
    parts = [p.strip() for p in text.split(',')]
    if len(parts) == 7:
        settings = load_settings()
        settings['dollar_cash'] = float(parts[0])
        settings['dollar_today'] = float(parts[1])
        settings['dollar_tomorrow'] = float(parts[2])
        settings['euro'] = float(parts[3])
        settings['lira_toman'] = float(parts[4])
        settings['lira_istanbul']['buy'] = float(parts[5])
        settings['lira_istanbul']['sell'] = float(parts[6])
        save_settings(settings)
        update.message.reply_text("قیمت‌ها با موفقیت به‌روزرسانی شدند.")
    else:
        update.message.reply_text(
            "فرمت ورودی صحیح نیست.
"
            "لطفاً به صورت:
"
            "دلار نقدی, دلار امروزی, دلار فردایی, یورو, لیر به تومان, لیر خرید استانبول, لیر فروش استانبول"
        )

# Function to send prices
def send_prices():
    settings = load_settings()
    message = (
        f"💱 قیمت‌های لحظه‌ای ارزها:

"
        f"- 💵 دلار نقدی: {settings['dollar_cash']} تومان
"
        f"- 💵 دلار امروزی: {settings['dollar_today']} تومان
"
        f"- 💵 دلار فردایی: {settings['dollar_tomorrow']} تومان
"
        f"- 💶 یورو: {settings['euro']} تومان
"
        f"- 🇹🇷 لیر به تومان: {settings['lira_toman']} تومان
"
        f"- 🏦 لیر استانبول:
"
        f"    - خرید: {settings['lira_istanbul']['buy']} تومان
"
        f"    - فروش: {settings['lira_istanbul']['sell']} تومان"
    )
    bot = Bot(API_TOKEN)
    bot.send_message(chat_id=CHANNEL_ID, text=message)

def main():
    # Start bot
    updater = Updater(API_TOKEN, use_context=True)
    dp = updater.dispatcher
    dp.add_handler(CommandHandler('update_prices', update_prices))

    # Scheduler to send prices every 1 minute
    scheduler = BackgroundScheduler()
    scheduler.add_job(send_prices, 'interval', minutes=1)
    scheduler.start()

    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()
